import React, { useEffect, useState } from 'react';
import { Link,useParams } from 'react-router-dom';
import {
  CCard, CCardBody, CCardHeader, CCol, CTable, CTableBody, CTableDataCell,
  CTableHead, CFormInput, CTableHeaderCell, CTableRow, CButton, CAlert, CNav, CNavItem, CNavLink, CTabContent, CTabPane
} from '@coreui/react';
import axios from 'axios';
import { gapi } from "gapi-script";
import * as XLSX from 'xlsx';
import { useLoading } from '../../layout/LoadingContext';
let sheetName="";
let sheetID="";
const GoogleSheetTable = ({ ActualUser, AuthUser }) => {
  const [sheetsData, setSheetsData] = useState([]);
  const [activeSheetIndex, setActiveSheetIndex] = useState(0);
  const [mergedRanges, setMergedRanges] = useState([]);
  const [ListOfColumnToVerify, setListOfColumnToVerify] = useState([]);
  const [editedRows, setEditedRows] = useState({});
  const [FormatedData, setFormatedData] = useState({});
  const [FormatedDataProperties, setFormatedDataProperties] = useState({});
  const [headerRowCount, setheaderRowCount] = useState(0);
  const [SubmittedData, setSubmittedData] = useState(false);
  const [FirstFewColumnToIgnore, setFirstFewColumnToIgnore] = useState(0);
  const [tableData, setTableData] = useState([]);
  const [errors, setErrors] = useState({});
  const { showLoading, hideLoading, API_KEY, DatabaseName, firestoreQueries } = useLoading();
  const [AllowedRowValue, setAllowedRowValue] = useState([]);
  const [sheetInfo, setSheetInfo] = useState([]);
  const [FullSettings, setFullSettings] = useState([]);
  const [formulasData, setFormulasData] = useState([]);
  const { ddoid } = useParams();

  useEffect(() => {
    fetchSheetInfo();
  }, []);

  // Fetch list of sheets from settings
  const fetchSheetInfo = async () => {
    try {
      showLoading();

      let expiryTimestamp;// Convert seconds to milliseconds
    const today = new Date();
        let GetUserData;
        console.log("ActualUser---->",ActualUser.ActualUser)
        console.log("ddoid---->",ddoid)
        if(typeof ddoid!=="undefined")
        {
           let  GetUserData1=await firestoreQueries.FetchDataFromCollection(DatabaseName, "users", 100, "uid", "==", ddoid);
            console.log("GetUserData---->",GetUserData1)
            if(GetUserData1.length)
            {
              GetUserData=GetUserData1[0];
            }

        }
        else if(typeof  ActualUser.ActualUser!=="undefined")
        {
          GetUserData=ActualUser.ActualUser;
        }
        else
        {
          GetUserData=ActualUser;
        }
       let  AllowedRowValue1 = Object.values(GetUserData.listoflinks);
        console.log("AllowedRowValue1---->",AllowedRowValue1)
       setAllowedRowValue(AllowedRowValue1)
      const settingsData = await firestoreQueries.FetchDataFromCollection(DatabaseName, "settings", 100, "sid", "==", 1);
      //

      let sheeturl="";
      let sheetnames=[];
      if (settingsData.length)
      {
          console.log("settingsData[0]----->",settingsData[0])
        sheeturl=settingsData[0].sheeturl;
        setFullSettings(settingsData[0])
        expiryTimestamp=new Date(settingsData[0].expiry.seconds * 1000);
        if(Object.keys(settingsData[0].sheetname).length)
        {
          sheetnames=Object.values(settingsData[0].sheetname);
        }
      }
      const sheetID1 = extractSheetID(sheeturl);
      sheetID=sheetID1;
      setSheetInfo(sheetnames.map(name => ({ sheetID, name })));
      if (expiryTimestamp > today)
      {
        fetchData(sheetID, sheetnames[0],settingsData[0].headerrows[0],settingsData[0].labelcolumn[0],settingsData[0].columntoverify[0]);
      }
      else
      {
        setErrors({ status: "error", submissionMessage: "Date For Submission Is Over .Please Contact Accounts CEO Baramulla.!" });
             hideLoading();
      }
    } catch (error) {
      console.error("Error fetching sheet info:", error);
      hideLoading();
    }
  };
const extractSheetID = (url) => {
    const regex = /https:\/\/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/;
    const match = url.match(regex);
    return match ? match[1] : null;
  };
  const roundToTwoDecimalPlaces = (num) => {
  const number = parseFloat(num); // Convert to a float number
  if (isNaN(number)) {
    return 0; // Return 0 or handle the error appropriately if num is not a valid number
  }
  return parseFloat(number.toFixed(3)); // Round to 2 decimal places
};
  // Fetch data for a specific sheet
  const fetchData = async (sheetID1, sheetName1,headerRowCount,LableColumnCount,vefifyfields) => {
    try {
      showLoading();
      const sheetResponse = await axios.get(`https://sheets.googleapis.com/v4/spreadsheets/${sheetID}?includeGridData=true&key=${API_KEY}`);
      sheetID=sheetID1;
      sheetName=sheetName1;
      const sheetData = sheetResponse.data.sheets.find(sheet => sheet.properties.title === sheetName);
      const rows = sheetData.data[0].rowData.map(row => row.values.map(cell => cell.formulaValue || cell.formattedValue || ''));
      const formulas = sheetData.data[0].rowData.map(row => row.values.map(cell => cell?.userEnteredValue?.formulaValue || ''));
      const mergedRanges = sheetData.merges || [];
      setheaderRowCount()
      setFormatedData(sheetData.data[0].rowData)
      setFormatedDataProperties(sheetData.data)
      setheaderRowCount(headerRowCount);
      setFirstFewColumnToIgnore(LableColumnCount);
      setSheetsData(prev => [...prev, { sheetName, rows }]);
      setMergedRanges(mergedRanges);
      setEditedRows(rows);
      setFormulasData(formulas);
      setListOfColumnToVerify(vefifyfields)
      setTableData(rows);
      hideLoading();
    } catch (error) {
      console.error("Error fetching sheet data:", error);
      hideLoading();
    }
  };

  // Switch tab and load data for the selected sheet
  const handleTabChange = (index) => {
    setActiveSheetIndex(index);

    if (sheetInfo[index]) {
      const { sheetID, name } = sheetInfo[index];

      fetchData(sheetID, name,FullSettings.headerrows[index],FullSettings.labelcolumn[index],FullSettings.columntoverify[index]);
    }
  };
const evaluateExpression = (expression, rowValues) => {
  const tokens = expression.split(/([-+*/])/).map(token => token.trim()); // Split by operators
console.log("tokens--->",tokens)

  const evaluatedTokens = tokens.map(token => {
    if (/^[A-Z]+\d+$/.test(token)) { // If it's a cell reference (e.g., E189)
      const colIndex = token.charCodeAt(0) - 65; // Convert letter to index
      console.log("token--->",token)
      console.log("colIndex--->",colIndex)
       console.log("rowValues--->",rowValues)
        console.log("rowValues[colIndex]--->",rowValues[colIndex])
      return parseFloat(rowValues[colIndex]) || 0; // Get the value from editedRows
    }
     console.log("token--->",token)
    return token; // Return the operator as is
  });

  // Evaluate the expression
  let result = evaluatedTokens[0]; // Start with the first token
  console.log("result--->",result)
  console.log("evaluatedTokens--->",evaluatedTokens)
  for (let i = 1; i < evaluatedTokens.length; i += 2) {
    const operator = evaluatedTokens[i];
    const value = evaluatedTokens[i + 1];
    switch (operator) {
      case '+':
        result += value;
        break;
      case '-':
        result -= value;
        break;
      case '*':
        result *= value;
        break;
      case '/':
        result /= value;
        break;
      default:
        break;
    }
  }

  return result;
};
  // Handle input changes
  const handleInputChange = (originalRowIndex, cellIndex, value) => {
    const updatedRows = {
      ...editedRows,
      [originalRowIndex]: {
        ...editedRows[originalRowIndex],
        [cellIndex]: value,
      },
    };

    // Update the corresponding formula cells dynamically
    const updatedFormulasRow = formulasData[originalRowIndex];
    if (updatedFormulasRow) {
      updatedFormulasRow.forEach((formula, formulaIndex) => {

        if (formula) {
        console.log("formula---->",formula)
          try {
            const rowValues = updatedRows[originalRowIndex];

            if (formula.includes("SUM")) {
            // Extract column indices from the formula (F189:H189)
            const matches = formula.match(/SUM\(([^)]+)\)/);
            if (matches) {
              const range = matches[1].split(':');
              const startCol = range[0].charCodeAt(0) - 65; // Convert letter to index
              const endCol = range[1].charCodeAt(0) - 65;

              // Sum the values from the specified columns only
              const cellValues = [];
              for (let colIndex = startCol; colIndex <= endCol; colIndex++) {
                const cellValue = parseFloat(rowValues[colIndex]) || 0; // Use the original row data
                cellValues.push(cellValue);
              }
				console.log("cellValues---->",cellValues)
              // Calculate the sum
              const sum = cellValues.reduce((acc, val) => acc + val, 0);
              updatedRows[originalRowIndex][formulaIndex] = sum; // Update the formula cell with sum
            }

            }
            else if (/^=\w+\d+([-+*/]\w+\d+)+$/.test(formula)) { // Check for expressions like =E189-I189
            const expression = formula.slice(1); // Remove the '=' sign
            console.log("expression---->",expression)
            const evaluatedValue = evaluateExpression(expression, updatedRows[originalRowIndex]);
            updatedRows[originalRowIndex][formulaIndex] = evaluatedValue; // Update the formula cell with evaluated value
          }










            /*if (formula.includes("SUM") || formula.includes("AVERAGE")) {
              const cellValues = Object.values(rowValues).map(value => parseFloat(value) || 0);
              console.log("cellValues---->",cellValues)
              const sum = cellValues.reduce((acc, val) => acc + val, 0);
              updatedRows[originalRowIndex][formulaIndex] = sum; // Update the formula cell with sum
            }*/
          } catch (error) {
            console.error("Error updating formula:", error);
          }
        }
      });
    }

    setEditedRows(updatedRows);  // Update state
  };
  const updateGoogleSheet = async (range,valuesF) => {
  try {
    const response = await fetch(" https://updategooglesheet-f6dijyh4qq-uc.a.run.app ", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        spreadsheetId: sheetID,
        range: range,
        valueInputOption: "USER_ENTERED",
        values: valuesF,
      }),
    });

    const result = await response.json();
    return result;
    //console.log(`${result.updatedCells} cells updated.`);
  } catch (error) {
    return error;
  }
};

const getColumnLetter = (colIndex) => {
  let letter = '';
  while (colIndex >= 0) {
    letter = String.fromCharCode((colIndex % 26) + 65) + letter;
    colIndex = Math.floor(colIndex / 26) - 1;
  }
  return letter;
};
/*const handleSubmitUpdates = async () => {
  try {
    showLoading();
   const filteredRows = Object.entries(editedRows)
      .filter(([rowIndex]) => AllowedRowValue.includes(tableData[parseInt(rowIndex)][1])) // Filter allowed rows
      .map(([rowIndex, updatedCells]) => {
        const updatedRow = tableData[parseInt(rowIndex)].map((cell, cellIndex) => {
          const formulaCell = formulasData[rowIndex]?.[cellIndex];
          return formulaCell ? formulaCell : updatedCells[cellIndex] || cell; // Send formula instead of value
        });

        return { rowIndex: parseInt(rowIndex), updatedRow };
      });


    const requests = filteredRows.map(({ rowIndex, updatedRow }) => {

      const filteredRow = updatedRow.map((cell, cellIndex) => {
        if (cellIndex < FirstFewColumnToIgnore) {
          return null;
        }
         if (formulasData[rowIndex]?.[cellIndex]) {
        return null;  // Filter out cells that have a formula
    }
        return cell;
      }).filter(cell => cell !== null);


      const lastColIndex = updatedRow.length - 1;
      const colLetter = lastColIndex >= 0 ? getColumnLetter(lastColIndex) : null;
      const colLetterFirst = lastColIndex >= 0 ? getColumnLetter(FirstFewColumnToIgnore) : null;

      if (!colLetter) return null;


      return {
        range: `${sheetName}!${colLetterFirst}${rowIndex + headerRowCount + 1}:${colLetter}${rowIndex + headerRowCount + 1}`,
        values: [filteredRow],
      };
    }).filter(request => request !== null);
console.log("requests---->",requests)
    const dataToSend = requests.filter(req => req.values[0].length > 0);
    console.log("dataToSend---->",dataToSend)
    const res={}
    //const res= await updateGoogleSheet(dataToSend[0].range,dataToSend[0].values)
    console.log("res---->",res)
    if(res.status==="success")
    {
      setSubmittedData(true);
      setErrors({ status: "success", submissionMessage: "Successfully Updated!" });
    }
    else
    {
      setErrors({ status: "error", submissionMessage: "Please Submit Again As It Was Not Saved!" });
    }
    hideLoading();
  } catch (error) {
    console.error("Error submitting updates:", error);
    hideLoading();
    setErrors({ status: "error", submissionMessage: "Failed to update data!" });
  }
};*/
const handleSubmitUpdates = async () => {
  try {
    showLoading();

    const filteredRows = Object.entries(editedRows)
      .filter(([rowIndex]) => AllowedRowValue.includes(tableData[parseInt(rowIndex)][1])) // Filter allowed rows
      .map(([rowIndex, updatedCells]) => {
        const updatedRow = tableData[parseInt(rowIndex)].map((cell, cellIndex) => {
          const formulaCell = formulasData[rowIndex]?.[cellIndex];

          // If formula exists, ensure it starts with `=` and includes the full formula like '=SUM(F10:H10)'
          if (formulaCell) {
            return `${formulaCell}`; // Assign formula to the cell
          } else {
            return updatedCells[cellIndex] || cell; // Otherwise, keep updated or original cell value
          }
        });

        return { rowIndex: parseInt(rowIndex), updatedRow };
      });

    const requests = filteredRows.map(({ rowIndex, updatedRow }) => {
      const filteredRow = updatedRow.map((cell, cellIndex) => {
        if (cellIndex < FirstFewColumnToIgnore) {
          return null;
        }
        // Exclude formula cells from the update if they don't need changes

        return cell;
      }).filter(cell => cell !== null);

      const lastColIndex = updatedRow.length - 1;
      const colLetter = lastColIndex >= 0 ? getColumnLetter(lastColIndex) : null;
      const colLetterFirst = lastColIndex >= 0 ? getColumnLetter(FirstFewColumnToIgnore) : null;

      if (!colLetter) return null;

      console.log("filteredRow====>", filteredRow);
      return {
        range: `${sheetName}!${colLetterFirst}${rowIndex + 1}:${colLetter}${rowIndex + 1}`,
        values: [filteredRow],
      };
    }).filter(request => request !== null);

    console.log("requests---->", requests);
    const dataToSend = requests.filter(req => req.values[0].length > 0);
    console.log("dataToSend---->", dataToSend);
    /*ListOfColumnToVerify.map((indexV,VValue)=>{
    console.log("indexV---->",indexV)
    if(indexV!=="IgnoreAlert")
    {
      //console.log("")
    }
    console.log("VValue---->",VValue)
    })*/
    if (dataToSend.length > 0) {
      const res = await updateGoogleSheet(dataToSend[0].range, dataToSend[0].values);
      console.log("res---->", res);

      if (res.status === "success") {
        setSubmittedData(true);
        setErrors({ status: "success", submissionMessage: "Successfully Updated!" });
      } else {
        setErrors({ status: "error", submissionMessage: "Please Submit Again As It Was Not Saved!" });
      }
    } else {
      console.log("No data to send to Google Sheets.");
      setErrors({ status: "info", submissionMessage: "No updates to save!" });
    }

    hideLoading();
  } catch (error) {
    console.error("Error submitting updates:", error);
    hideLoading();
    setErrors({ status: "error", submissionMessage: "Failed to update data!" });
  }
};


  // Update Google Sheets with edited rows for each sheet


  // Export data for the active sheet
  /*const exportToExcel = () => {
    const { rows } = sheetsData[activeSheetIndex];
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(rows);
    XLSX.utils.book_append_sheet(wb, ws, sheetInfo[activeSheetIndex].name);
    XLSX.writeFile(wb, `${sheetInfo[activeSheetIndex].name}_Export.xlsx`);
  };*/
  const exportSelectedRowsToExcel = (googleSheetData, formatting, selectedRows) => {
  const selectedData = selectSpecificRows(googleSheetData, selectedRows);
  const selectedFormatting = selectSpecificRowsData(formatting, selectedRows);
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(selectedFormatting);


  XLSX.utils.book_append_sheet(wb, ws, sheetName);

  // Save the Excel file
  XLSX.writeFile(wb, "SelectedExport.xlsx");
};
const selectAndFlattenRows = (sheetData, selectedRows) => {
  const selected = selectedRows.map(rowIndex => sheetData[rowIndex]);
  return flattenRowData(selected); // Flatten the data to array of arrays
};
 const selectSpecificRows = (sheetData, selectedRows) => {
  return selectedRows.map(rowIndex => {
    const row = sheetData[rowIndex].values; // Extract the cell values

  return row;
    //return row.map(cell => (cell.formattedValue ? cell.formattedValue : '')); // Ensure each cell contains a value
  });
};
 const selectSpecificRowsData = (sheetData, selectedRows) => {
  return selectedRows.map(rowIndex => {
    const row = sheetData[rowIndex].values; // Extract the cell values
    const transformedRows =Object.entries(editedRows[rowIndex]).map(([key, value])=>value)
    //return editedRows[rowIndex]?editedRows[rowIndex]:sheetData[rowIndex].values;
    //return row;
      return transformedRows;
    //return editedRows[rowIndex].map(cell => (cell.formattedValue ? cell.formattedValue : '')); // Ensure each cell contains a value
  });
};
   const exportToExcel = () => {

    let SelectRowsAre=[];
    let ToexportData=[];
    Array.from({ length: headerRowCount }, (_, rowIndex) => {
    ToexportData.push(tableData[rowIndex]);
    SelectRowsAre.push(rowIndex)
    })
     const filteredRows = Object.entries(editedRows)
      .filter(([rowIndex]) => AllowedRowValue.includes(tableData[parseInt(rowIndex)][1])) // Filter allowed rows
      .map(([rowIndex, updatedCells]) => {
        const updatedRow = tableData[parseInt(rowIndex)].map((cell, cellIndex) => {
          const formulaCell = formulasData[rowIndex]?.[cellIndex];
          return editedRows[rowIndex]?.[cellIndex]?editedRows[rowIndex]?.[cellIndex] : cell; // Send formula instead of value
        });

        return { rowIndex: parseInt(rowIndex), updatedRow };
      });

    // Prepare requests for batch update
    const requests = filteredRows.map(({ rowIndex, updatedRow }) => {
      // Filter out cells that should not be updated (ignored columns)
      const filteredRow = updatedRow.map((cell, cellIndex) => {
        /*if (cellIndex < FirstFewColumnToIgnore) {
          return null; // Ignore first few columns
        }*/
        return cell; // Keep the cell (formula or updated value)
      }).filter(cell => cell !== null); // Remove null values from the row

      // Get the range (column letters)
      const lastColIndex = updatedRow.length - 1;
      const colLetter = lastColIndex >= 0 ? getColumnLetter(lastColIndex) : null;
      const colLetterFirst = lastColIndex >= 0 ? getColumnLetter(FirstFewColumnToIgnore) : null;

      // If there's no valid column, skip this request
      if (!colLetter) return null;
      SelectRowsAre.push(rowIndex)
      // Return the update request for this row
      ToexportData.push(filteredRow)
      return filteredRow
    }).filter(request => request !== null); // Filter out null requests


  exportSelectedRowsToExcel(FormatedData,FormatedData,SelectRowsAre);
  };
 const getMergedCellIndex = (rowIndex, cellIndex) => {
    const mergedRange = mergedRanges.find(range => {
      const startRow = range.startRowIndex;
      const endRow = range.endRowIndex;
      const startCol = range.startColumnIndex;
      const endCol = range.endColumnIndex;

      return (
        rowIndex >= startRow && rowIndex < endRow &&
        cellIndex >= startCol && cellIndex < endCol
      );
    });
  if (mergedRange) {
      return {
        endRowIndex: mergedRange.endRowIndex,
        startRowIndex:mergedRange.startRowIndex,
        endColumnIndex: mergedRange.endColumnIndex,
         startColumnIndex:mergedRange.startColumnIndex
      };
    }


    return { startRowIndex: -2, endRowIndex: -2, endColumnIndex: -2, startColumnIndex: -2};
  };
  const getMergedCellSpan = (rowIndex, cellIndex) => {
    const mergedRange = mergedRanges.find(range => {
      const startRow = range.startRowIndex;
      const endRow = range.endRowIndex;
      const startCol = range.startColumnIndex;
      const endCol = range.endColumnIndex;

      return (
        rowIndex >= startRow && rowIndex < endRow &&
        cellIndex >= startCol && cellIndex < endCol
      );
    });

    if (mergedRange) {
      return {
        rowSpan: mergedRange.endRowIndex - mergedRange.startRowIndex,
        colSpan: mergedRange.endColumnIndex - mergedRange.startColumnIndex,
      };
    }

    return { rowSpan: 1, colSpan: 1 };
  };
 /* const renderHeaders = (rows) => {
    return (
      <CTableHead>
        <CTableRow>
          {rows[0]?.map((header, index) => (
            <CTableHeaderCell key={index}>{header || ''}</CTableHeaderCell>
          ))}
        </CTableRow>
      </CTableHead>
    );
  };*/
const renderHeaders = () => {
    return (
      <>
      <CTableHead>
        {Array.from({ length: headerRowCount }, (_, rowIndex) => {
          let skipColumns = 0;
          return (
            <CTableRow key={rowIndex}>
              {tableData[rowIndex]?.map((headerCell, cellIndex) => {
                if (skipColumns > 0) {
                  skipColumns--;
                  return null;
                }

                const { rowSpan, colSpan } = getMergedCellSpan(rowIndex, cellIndex);

                if (colSpan > 1) {
                  skipColumns = colSpan - 1;
                }

                return (
                  <CTableHeaderCell
                    key={cellIndex}
                    rowSpan={rowSpan}
                    colSpan={colSpan}
                  >
                    {headerCell || ''}
                  </CTableHeaderCell>
                );
              })}
            </CTableRow>
          );
        })}
        </CTableHead>
      </>
    );
  };


  const renderTableBody = () => {
  console.log("AllowedRowValue---->",AllowedRowValue)
    return tableData
      .map((row, originalRowIndex) => {
        if (!AllowedRowValue.includes(row[1])) return null;
        return (
          <CTableRow key={originalRowIndex}>
            {row.map((cell, cellIndex) => {
              const { rowSpan, colSpan } = getMergedCellSpan(originalRowIndex , cellIndex);
              const isFormulaCell = !!formulasData[originalRowIndex ]?.[cellIndex];

              return (
                <CTableDataCell
                	rownumber={originalRowIndex}
                	columnnumber={cellIndex}
                  key={cellIndex}
                  rowSpan={rowSpan}
                  colSpan={colSpan}
                >
                  {cellIndex >= FirstFewColumnToIgnore ? (
                    isFormulaCell ? (
                      <span>{roundToTwoDecimalPlaces(editedRows[originalRowIndex]?.[cellIndex]) || cell}</span> // Show formula cells as non-editable
                    ) : (
                      <CFormInput
                        type="text"
                        vakklue={editedRows[originalRowIndex]?.[cellIndex] }
                        value={editedRows[originalRowIndex]?.[cellIndex]}
                        invalid={!!errors[originalRowIndex]}
                        onChange={(e) => handleInputChange(originalRowIndex, cellIndex, e.target.value)}
                      />
                    )
                  ) : (
                    cell || ''
                  )}
                </CTableDataCell>
              );
            })}
          </CTableRow>
        );
      });
  };

  return (
    <CCol xs={12}>
      <CCard className="mb-4">
        <CCardHeader>
          <strong>Google Sheets Data</strong>
        </CCardHeader>
        <CCardBody>
          {/* Tabs for each sheet */}
          <CNav variant="tabs">
            {sheetInfo.map((info, index) => (
              <CNavItem key={index}>
                <CNavLink
                  active={activeSheetIndex === index}
                  onClick={() => handleTabChange(index)}
                >
                  {info.name}
                </CNavLink>
              </CNavItem>
            ))}
          </CNav>

          {/* Content for each tab */}
          <CTabContent>
            {sheetsData.map((sheetData, index) => (
              <CTabPane key={index} visible={activeSheetIndex === index} className="overfolowscroll">
                <CTable color="success" bordered>
                  {renderHeaders(sheetData.rows)}
                  <CTableBody>
                  {renderTableBody(sheetData.rows, index)}
                  </CTableBody>
                </CTable>

                <CButton color="primary" onClick={handleSubmitUpdates}>Update Sheet</CButton>
                {SubmittedData && (

          <CButton color="warning" className="m-4" onClick={exportToExcel}>Export</CButton>

          )}
              </CTabPane>
            ))}
          </CTabContent>

          {errors.status && (
            <CAlert color={errors.status === "error" ? "danger" : "success"}>
              {errors.submissionMessage}
            </CAlert>
          )}
        </CCardBody>
      </CCard>
    </CCol>
  );
};

export default GoogleSheetTable;
